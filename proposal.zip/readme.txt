Project: Galactical Paintball
Creator/Author : Nandor Nagy
Description: MERN Project with CRUD functionality
Created in: VS Code
Estimated Time to finish the work: 2 Weeks
Extra info:
	* I made this in Coding Dojo Bootcamp for P&A SoloProject
	* This webpage let you to discover a free time activity
	* You have to Login to access DB, CRUD
	* Everything is free to use, i don't used money for creating this project
	